import assert from 'node:assert/strict';
import test from 'node:test';
import { resolveClaudeCodeExecutablePath, } from '../../shared/claude-cli-path.js';
test('resolveClaudeCodeExecutablePath resolves the npm Claude wrapper to its native exe on Windows', () => {
    const wrapperDir = 'C:\\nvm4w\\nodejs';
    const nativePath = `${wrapperDir}\\node_modules\\@anthropic-ai\\claude-code\\bin\\claude.exe`;
    const execFileSync = (() => `${wrapperDir}\\claude\r\n${wrapperDir}\\claude.cmd\r\n`);
    const readFileSync = (() => '');
    const resolved = resolveClaudeCodeExecutablePath('claude', {
        platform: 'win32',
        execFileSync,
        existsSync: (candidate) => candidate === nativePath,
        readFileSync,
    });
    assert.equal(resolved, nativePath);
});
test('resolveClaudeCodeExecutablePath keeps an explicit JavaScript launcher path unchanged', () => {
    const scriptPath = 'C:\\tools\\claude.js';
    const resolved = resolveClaudeCodeExecutablePath(scriptPath, {
        platform: 'win32',
    });
    assert.equal(resolved, scriptPath);
});
test('resolveClaudeCodeExecutablePath can parse a wrapper file path containing letters r and n before claude.exe', () => {
    const wrapperPath = 'C:\\tools\\claude';
    const nativePath = 'C:\\tools\\custom\\bin\\node_modules\\@anthropic-ai\\claude-code\\bin\\claude.exe';
    const readFileSync = (() => `exec "$basedir/custom/bin/node_modules/@anthropic-ai/claude-code/bin/claude.exe" "$@"`);
    const resolved = resolveClaudeCodeExecutablePath(wrapperPath, {
        platform: 'win32',
        existsSync: (candidate) => candidate === nativePath,
        readFileSync,
    });
    assert.equal(resolved, nativePath);
});
test('resolveClaudeCodeExecutablePath keeps an explicitly configured command when PATH lookup fails', () => {
    const execFileSync = (() => {
        throw new Error('not found');
    });
    const resolved = resolveClaudeCodeExecutablePath('claude', {
        platform: 'win32',
        execFileSync,
    });
    assert.equal(resolved, 'claude');
});
test('resolveClaudeCodeExecutablePath returns undefined on Windows when the default resolves to nothing', () => {
    // The SDK spawns this path directly, so a bare `claude` would fail with
    // "native binary not found at claude"; undefined means "use your own binary".
    const execFileSync = (() => {
        throw new Error('not found');
    });
    const resolved = resolveClaudeCodeExecutablePath(undefined, {
        platform: 'win32',
        execFileSync,
    });
    assert.equal(resolved, undefined);
});
test('resolveClaudeCodeExecutablePath returns undefined when every wrapper on PATH is a JavaScript launcher', () => {
    // An older global install ships cli.js and no bin/claude.exe, so nothing on
    // PATH maps to a native binary the SDK can spawn.
    const wrapperDir = 'C:\\Users\\dev\\AppData\\Roaming\\npm';
    const execFileSync = (() => `${wrapperDir}\\claude\r\n${wrapperDir}\\claude.cmd\r\n`);
    const readFileSync = (() => 'exec node "$basedir/node_modules/@anthropic-ai/claude-code/cli.js" "$@"');
    const resolved = resolveClaudeCodeExecutablePath(undefined, {
        platform: 'win32',
        execFileSync,
        existsSync: () => false,
        readFileSync,
    });
    assert.equal(resolved, undefined);
});
test('resolveClaudeCodeExecutablePath still resolves the native exe when both installs are on PATH', () => {
    const staleDir = 'C:\\Users\\dev\\AppData\\Roaming\\npm';
    const nativeDir = 'C:\\nvm4w\\nodejs';
    const nativePath = `${nativeDir}\\node_modules\\@anthropic-ai\\claude-code\\bin\\claude.exe`;
    const execFileSync = (() => `${staleDir}\\claude\r\n${nativeDir}\\claude\r\n`);
    const readFileSync = (() => 'exec node "$basedir/node_modules/@anthropic-ai/claude-code/cli.js" "$@"');
    const resolved = resolveClaudeCodeExecutablePath(undefined, {
        platform: 'win32',
        execFileSync,
        existsSync: (candidate) => candidate === nativePath,
        readFileSync,
    });
    assert.equal(resolved, nativePath);
});
test('resolveClaudeCodeExecutablePath leaves non-Windows platforms on the bare command', () => {
    const resolved = resolveClaudeCodeExecutablePath(undefined, { platform: 'linux' });
    assert.equal(resolved, 'claude');
});
//# sourceMappingURL=claude-cli-path.test.js.map