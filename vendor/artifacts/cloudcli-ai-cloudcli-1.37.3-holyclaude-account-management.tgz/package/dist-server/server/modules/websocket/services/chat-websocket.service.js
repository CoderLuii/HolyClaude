import path from 'node:path';
import { sessionsDb } from '../../../modules/database/index.js';
import { providerModelsService, sessionsService } from '../../../modules/providers/index.js';
import { chatRunRegistry } from '../../../modules/websocket/services/chat-run-registry.service.js';
import { connectedClients, WS_OPEN_STATE } from '../../../modules/websocket/services/websocket-state.service.js';
import { getGlobalImageAssetsDir, isImageAttachmentDescriptor, normalizeAttachmentDescriptors, } from '../../../shared/image-attachments.js';
import { parseIncomingJsonObject } from '../../../shared/utils.js';
/**
 * Trust boundary for client-supplied image attachments: chat.send options come
 * straight from the browser, and the provider runtimes read the referenced
 * files off disk (Claude base64-encodes them into the prompt). Only images
 * that live directly inside the global upload store (`~/.cloudcli/assets`,
 * where POST /api/assets/images puts them) are allowed through — anything
 * else (absolute paths elsewhere, traversal, subdirectories) is dropped.
 *
 * Exported for tests; `assetsRootOverride` exists only for them.
 */
export function filterAttachmentsToUploadStore(attachments, assetsRootOverride) {
    const assetsRoot = path.resolve(assetsRootOverride ?? getGlobalImageAssetsDir());
    return normalizeAttachmentDescriptors(attachments).filter((descriptor) => {
        // Relative paths are anchored in the store; absolute ones must already be in it.
        const resolved = path.resolve(assetsRoot, descriptor.path);
        const relative = path.relative(assetsRoot, resolved);
        const isDirectChild = relative.length > 0 &&
            !relative.startsWith('..') &&
            !path.isAbsolute(relative) &&
            !relative.includes(path.sep) &&
            !relative.includes('/');
        if (!isDirectChild) {
            console.warn(`[Chat] Dropping attachment outside the upload store: ${descriptor.path}`);
        }
        return isDirectChild;
    });
}
/** Backward-compatible image filter consumed by existing websocket tests. */
export function filterImagesToUploadStore(images, assetsRootOverride) {
    return filterAttachmentsToUploadStore(images, assetsRootOverride);
}
/**
 * Extracts the authenticated request user id in the formats currently produced
 * by platform and OSS auth code paths.
 */
function readRequestUserId(request) {
    const user = request?.user;
    if (!user) {
        return null;
    }
    if (typeof user.id === 'string' || typeof user.id === 'number') {
        return user.id;
    }
    if (typeof user.userId === 'string' || typeof user.userId === 'number') {
        return user.userId;
    }
    return null;
}
function sendJson(ws, payload) {
    if (ws.readyState === WS_OPEN_STATE) {
        ws.send(JSON.stringify(payload));
    }
}
/**
 * Reports a protocol-level failure to the requesting client.
 *
 * Protocol errors deliberately use their own `kind` (instead of the provider
 * `error` message kind) so the frontend can distinguish "your request was
 * invalid" from "the model run produced an error" without inspecting text.
 */
function sendProtocolError(ws, code, error, sessionId) {
    sendJson(ws, {
        kind: 'protocol_error',
        code,
        error,
        sessionId: sessionId ?? null,
        timestamp: new Date().toISOString(),
    });
}
function readRequiredSessionId(data) {
    const sessionId = typeof data.sessionId === 'string' ? data.sessionId.trim() : '';
    return sessionId.length > 0 ? sessionId : null;
}
/**
 * Handles `chat.send`: resolves the session row (provider, project path, and
 * provider-native id all come from the database — never from the client),
 * registers the run, and dispatches to the provider runtime.
 */
async function handleChatSend(ws, userId, data, dependencies) {
    const resolved = resolveSendTarget(ws, data, dependencies, 'chat.send');
    if (!resolved) {
        return;
    }
    await dispatchRun(ws, userId, resolved.sessionId, resolved.session, data, dependencies);
}
/**
 * Shared front half of `chat.send` and `chat.edit-send`: the session row and
 * provider come from the database, never from the client.
 */
function resolveSendTarget(ws, data, dependencies, frameName) {
    const sessionId = readRequiredSessionId(data);
    if (!sessionId) {
        sendProtocolError(ws, 'SESSION_ID_REQUIRED', `${frameName} requires a sessionId.`);
        return null;
    }
    const session = sessionsDb.getSessionById(sessionId);
    if (!session) {
        sendProtocolError(ws, 'SESSION_NOT_FOUND', `Session "${sessionId}" was not found. Create it via POST /api/providers/sessions first.`, sessionId);
        return null;
    }
    const provider = session.provider;
    if (!dependencies.runtime.hasRuntime(provider)) {
        sendProtocolError(ws, 'UNSUPPORTED_PROVIDER', `Provider "${provider}" is not available.`, sessionId);
        return null;
    }
    return { sessionId, session, provider };
}
/**
 * Registers the run and hands the turn to the provider runtime.
 *
 * `extraRuntimeOptions` is how an edited message asks the provider to resume
 * partway instead of continuing from the tip; a normal send passes nothing.
 */
async function dispatchRun(ws, userId, sessionId, session, data, dependencies, extraRuntimeOptions = {}, beforeRun) {
    const provider = session.provider;
    const run = chatRunRegistry.startRun({
        appSessionId: sessionId,
        provider,
        providerSessionId: session.provider_session_id,
        connection: ws,
        userId,
    });
    if (!run) {
        if (ws) {
            sendProtocolError(ws, 'RUN_IN_PROGRESS', `Session "${sessionId}" already has a run in progress.`, sessionId);
        }
        return { started: false, error: 'A run is already in progress for this session.' };
    }
    const clientOptions = (data.options ?? {});
    const command = typeof data.content === 'string' ? data.content : '';
    // Record what this turn runs with so reopening the session later restores the
    // same model and reasoning effort, and so the resume path has a
    // session-scoped model answer to use.
    if (typeof clientOptions.model === 'string' && clientOptions.model.trim()) {
        providerModelsService.setSessionModel(provider, sessionId, clientOptions.model);
    }
    if (typeof clientOptions.effort === 'string' && clientOptions.effort.trim()) {
        providerModelsService.setSessionEffort(provider, sessionId, clientOptions.effort);
    }
    const attachmentCandidates = [
        ...normalizeAttachmentDescriptors(clientOptions.images),
        ...normalizeAttachmentDescriptors(clientOptions.files),
        ...normalizeAttachmentDescriptors(clientOptions.attachments),
    ];
    const verifiedAttachments = filterAttachmentsToUploadStore(attachmentCandidates);
    const uniqueAttachments = verifiedAttachments.filter((descriptor, index, all) => all.findIndex((candidate) => candidate.path === descriptor.path) === index);
    // The provider runtimes receive the stable app session id. When their
    // CLI/SDK needs the provider-native id for resume, they resolve it from the
    // session row themselves (sessionsService.resolveProviderSessionId).
    // Brand-new sessions have no provider id yet, so the runtime starts fresh
    // and announces one, which the gateway writer captures and maps back to the
    // app session id.
    const runtimeOptions = {
        ...clientOptions,
        ...extraRuntimeOptions,
        // Attachments are re-validated server-side: only direct children of the
        // global upload store may reach provider runtimes or their file tools.
        attachments: uniqueAttachments,
        images: uniqueAttachments.filter(isImageAttachmentDescriptor),
        files: uniqueAttachments.filter((descriptor) => !isImageAttachmentDescriptor(descriptor)),
        sessionId,
        cwd: clientOptions.cwd ?? session.project_path ?? undefined,
        projectPath: session.project_path ?? clientOptions.projectPath,
    };
    let failure = null;
    try {
        // Runs only now that the session is reserved, because an edit rewinds the
        // conversation here and a rewind for a run that was never admitted cannot
        // be taken back. Inside the try so a rewind that throws still releases the
        // run instead of leaving the session processing forever.
        await beforeRun?.(run);
        await dependencies.runtime.run(provider, command, runtimeOptions, run.writer);
    }
    catch (error) {
        failure = error instanceof Error ? error.message : String(error);
        console.error(`[Chat] Provider runtime "${provider}" failed`, { sessionId, error: failure });
    }
    finally {
        // Safety net: a runtime that crashed (or resolved) without emitting its
        // terminal `complete` would otherwise leave the session stuck in
        // "processing" forever on every connected client. Scoped to THIS run —
        // a queued message can start the session's next run before this promise
        // settles, and the session-keyed completeRun would kill that new run.
        chatRunRegistry.completeRunIfCurrent(run, { exitCode: 1 });
    }
    return { started: true, error: failure };
}
/**
 * Handles `chat.edit-send`: replaces an already-sent message and everything
 * after it with a new turn.
 *
 * Nothing is deleted. The provider resumes the conversation partway and
 * appends the replacement, so the abandoned attempt stays in the transcript
 * file and is simply no longer part of the live conversation — the same shape
 * Claude Code's rewind and Codex's fork-with-cut-point produce.
 */
async function handleChatEditSend(ws, userId, data, dependencies) {
    const resolved = resolveSendTarget(ws, data, dependencies, 'chat.edit-send');
    if (!resolved) {
        return;
    }
    const { sessionId, session, provider } = resolved;
    const anchorId = typeof data.anchorId === 'string' ? data.anchorId.trim() : '';
    if (!anchorId) {
        sendProtocolError(ws, 'ANCHOR_REQUIRED', 'chat.edit-send requires the anchorId of the message being replaced.', sessionId);
        return;
    }
    let resumeThroughId;
    try {
        const anchor = await sessionsService.resolveEditAnchor(sessionId, anchorId);
        if (!anchor) {
            sendProtocolError(ws, 'EDIT_NOT_SUPPORTED', `Provider "${provider}" cannot replace an already-sent message.`, sessionId);
            return;
        }
        if (!anchor.found) {
            sendProtocolError(ws, 'ANCHOR_NOT_FOUND', 'That message is no longer in the transcript.', sessionId);
            return;
        }
        resumeThroughId = anchor.resumeThroughId;
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        sendProtocolError(ws, 'ANCHOR_LOOKUP_FAILED', `Could not read the transcript: ${message}`, sessionId);
        return;
    }
    // Providers split here on what their runtime can do. Claude resumes its
    // transcript partway, so the anchor rides along as a run option. Codex
    // cannot — a thread only grows — so the conversation is rewound on disk and
    // the run that follows is an ordinary resume of whatever the session then
    // points at. Which of the two applies is decided here; the rewind itself
    // waits until the run has actually been admitted.
    const rewinds = sessionsService.providerRewindsForEdit(sessionId);
    await dispatchRun(ws, userId, sessionId, session, data, dependencies, 
    // `null` is meaningful: the edited turn was the first prompt, so the
    // conversation starts over instead of resuming.
    rewinds
        ? {}
        : { resumeAnchorId: resumeThroughId ?? undefined, resumeFromScratch: resumeThroughId === null }, async (run) => {
        // Emitted through the run's writer so it is sequenced and replayed like
        // any other event — a second tab watching this session has to truncate
        // too.
        //
        // Before the rewind, not after it. A rewind that has to branch spawns a
        // process and waits on a JSON-RPC round trip, and holding the frame
        // until that came back left the message the user had just edited away
        // sitting on screen for about a second — the very flicker this feature
        // exists to avoid. Announcing first is safe because a rewind that fails
        // still ends the run, and the terminal `complete` makes every client
        // re-read the transcript, which puts back anything that turned out not
        // to have been replaced after all.
        run.writer.send({
            kind: 'history_truncated',
            provider,
            sessionId,
            anchorId,
        });
        if (rewinds) {
            try {
                await sessionsService.rewindSessionForEdit(sessionId, resumeThroughId);
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                sendProtocolError(ws, 'EDIT_REWIND_FAILED', `Could not rewind the conversation: ${message}`, sessionId);
                // Ends the run before the provider is asked to continue a
                // conversation that was not rewound after all.
                throw error;
            }
        }
    });
}
/**
 * Handles `chat.abort`: cancels the run for one app session and emits the
 * terminal `complete` on its behalf (runtimes skip their own complete for
 * aborted runs, and the registry drops any duplicate).
 */
async function handleChatAbort(ws, data, dependencies) {
    const sessionId = readRequiredSessionId(data);
    if (!sessionId) {
        sendProtocolError(ws, 'SESSION_ID_REQUIRED', 'chat.abort requires a sessionId.');
        return;
    }
    const run = chatRunRegistry.getRun(sessionId);
    if (!run || run.status !== 'running') {
        sendProtocolError(ws, 'NO_ACTIVE_RUN', `Session "${sessionId}" has no active run.`, sessionId);
        return;
    }
    const success = await dependencies.runtime.abort(run.provider, sessionId);
    chatRunRegistry.completeRun(sessionId, {
        exitCode: success ? 0 : 1,
        aborted: true,
    });
}
/**
 * Handles `chat.subscribe`: for each requested session, reports whether a run
 * is processing, re-attaches the live stream to this socket, replays missed
 * events (seq > lastSeq), and includes pending permission requests.
 *
 * This single message replaces the old `check-session-status`,
 * `get-pending-permissions`, and Claude-only writer reconnect flows.
 */
function handleChatSubscribe(ws, data, dependencies) {
    const targets = Array.isArray(data.sessions) ? data.sessions : [];
    for (const target of targets) {
        if (!target || typeof target !== 'object') {
            continue;
        }
        const sessionId = typeof target.sessionId === 'string'
            ? target.sessionId.trim()
            : '';
        if (!sessionId) {
            continue;
        }
        const lastSeqRaw = target.lastSeq;
        const lastSeq = typeof lastSeqRaw === 'number' && Number.isFinite(lastSeqRaw)
            ? Math.max(0, Math.floor(lastSeqRaw))
            : 0;
        const run = chatRunRegistry.getRun(sessionId);
        const isProcessing = chatRunRegistry.isProcessing(sessionId);
        // Future live events for this run should land on the socket that asked —
        // this is what makes mid-stream page refreshes work for all providers.
        if (isProcessing) {
            chatRunRegistry.attachConnection(sessionId, ws);
        }
        // Pending approvals are tracked under the app session id inside the
        // Claude runtime, so they can be looked up directly.
        const pendingPermissions = dependencies.runtime.getPendingApprovalsForSession(sessionId);
        sendJson(ws, {
            kind: 'chat_subscribed',
            sessionId,
            isProcessing,
            lastSeq: run?.lastSeq ?? 0,
            pendingPermissions,
            timestamp: new Date().toISOString(),
        });
        // Replay only for RUNNING runs, strictly after the ack. Completed runs
        // are fully persisted to the provider transcript and served over REST —
        // replaying them (e.g. after a page reload where the client's lastSeq is
        // 0) would duplicate messages the history fetch already returned.
        if (isProcessing) {
            for (const event of chatRunRegistry.replayEvents(sessionId, lastSeq)) {
                sendJson(ws, event);
            }
        }
    }
}
/**
 * Handles `chat.permission-response`: forwards a tool-approval decision to the
 * pending approval resolver (Claude is the only provider with interactive
 * approvals today, but the message is intentionally provider-neutral).
 */
function handlePermissionResponse(data, dependencies) {
    if (typeof data.requestId !== 'string' || data.requestId.length === 0) {
        return;
    }
    dependencies.runtime.resolveToolApproval(data.requestId, {
        allow: Boolean(data.allow),
        updatedInput: data.updatedInput,
        message: typeof data.message === 'string' ? data.message : undefined,
        rememberEntry: data.rememberEntry,
    });
}
/**
 * Handles authenticated chat websocket messages used by the main chat panel.
 *
 * Inbound protocol (client to server):
 * - `chat.send`                { sessionId, content, options? }
 * - `chat.abort`               { sessionId }
 * - `chat.subscribe`           { sessions: [{ sessionId, lastSeq? }] }
 * - `chat.permission-response` { requestId, allow, updatedInput?, message?, rememberEntry? }
 *
 * Outbound protocol (server to client): every frame is `kind`-based — either
 * a provider `NormalizedMessage` (with `seq`) or a gateway event
 * (`chat_subscribed`, `session_upserted`, `loading_progress`,
 * `protocol_error`).
 */
/**
 * Runs a turn for a session with no client attached.
 *
 * Used by scheduled messages, which fire from a timer: there is no socket to
 * report errors to and no audience to stream to. The run is registered exactly
 * like an interactive one, so anyone who opens the session while it is going
 * subscribes and replays it from the start, and the session shows as busy
 * everywhere in the meantime.
 *
 * Resolves when the provider run settles. Returns false when the session has
 * gone away or is busy without `interruptActiveRun`, which the caller reports
 * on the schedule.
 */
export async function runDetachedChatTurn(input, dependencies) {
    const session = sessionsDb.getSessionById(input.sessionId);
    if (!session) {
        return { started: false, error: 'The session no longer exists.' };
    }
    const provider = session.provider;
    if (!dependencies.runtime.hasRuntime(provider)) {
        return { started: false, error: `Provider "${provider}" is not available.` };
    }
    const activeRun = chatRunRegistry.getRun(input.sessionId);
    if (activeRun && activeRun.status === 'running') {
        if (!input.interruptActiveRun) {
            return { started: false, error: 'A run was already in progress for this session.' };
        }
        // Same shape as `chat.abort`: cancel the provider run and emit the
        // terminal `complete` on its behalf, so every watching client sees the
        // interrupted run end before this turn's stream begins. The interrupted
        // run's own dispatch settles later through completeRunIfCurrent, which is
        // scoped to that run and cannot touch the one started here.
        const aborted = await dependencies.runtime.abort(activeRun.provider, input.sessionId);
        chatRunRegistry.completeRun(input.sessionId, {
            exitCode: aborted ? 0 : 1,
            aborted: true,
        });
    }
    return dispatchRun(null, input.userId, input.sessionId, session, { sessionId: input.sessionId, content: input.content, options: input.options ?? {} }, dependencies);
}
export function handleChatConnection(ws, request, dependencies) {
    console.log('[INFO] Chat WebSocket connected');
    connectedClients.add(ws);
    const userId = readRequestUserId(request);
    ws.on('message', async (rawMessage) => {
        try {
            const parsed = parseIncomingJsonObject(rawMessage);
            if (!parsed) {
                throw new Error('Invalid websocket payload');
            }
            const data = parsed;
            const messageType = typeof data.type === 'string' ? data.type : '';
            switch (messageType) {
                case 'chat.edit-send':
                    await handleChatEditSend(ws, userId, data, dependencies);
                    return;
                case 'chat.send':
                    await handleChatSend(ws, userId, data, dependencies);
                    return;
                case 'chat.abort':
                    await handleChatAbort(ws, data, dependencies);
                    return;
                case 'chat.subscribe':
                    handleChatSubscribe(ws, data, dependencies);
                    return;
                case 'chat.permission-response':
                    handlePermissionResponse(data, dependencies);
                    return;
                default:
                    sendProtocolError(ws, 'UNKNOWN_MESSAGE_TYPE', `Unknown message type "${messageType}".`);
                    return;
            }
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            console.error('[ERROR] Chat WebSocket error:', message);
            sendProtocolError(ws, 'INTERNAL_ERROR', message);
        }
    });
    ws.on('close', () => {
        console.log('[INFO] Chat client disconnected');
        connectedClients.delete(ws);
    });
}
//# sourceMappingURL=chat-websocket.service.js.map