import { randomUUID } from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { projectsDb, sessionsDb } from '../../../modules/database/index.js';
import { broadcastSessionUpserted, chatRunRegistry } from '../../../modules/websocket/index.js';
import { providerRegistry } from '../../../modules/providers/provider.registry.js';
import { sessionHistoryCache } from '../../../modules/providers/services/session-history-cache.service.js';
import { AppError, sliceTailPage } from '../../../shared/utils.js';
const MAX_CLOUDCLI_SESSION_NAME_WORDS = 4;
function buildCloudCliSessionName(initialMessage) {
    const words = initialMessage.trim().split(/\s+/).filter(Boolean);
    return words.slice(0, MAX_CLOUDCLI_SESSION_NAME_WORDS).join(' ') || 'Untitled Session';
}
/**
 * Removes one file if it exists.
 */
async function removeFileIfExists(filePath) {
    try {
        await fsp.unlink(filePath);
        return true;
    }
    catch (error) {
        const code = error.code;
        if (code === 'ENOENT') {
            return false;
        }
        throw error;
    }
}
/**
 * Archive rows need a stable project label even when the owning project is not
 * part of the active sidebar payload. This lightweight resolver keeps the
 * archive API self-contained while still matching the project's stored display
 * name when one exists.
 */
function resolveProjectDisplayName(projectPath, customProjectName) {
    const trimmedCustomName = typeof customProjectName === 'string' ? customProjectName.trim() : '';
    if (trimmedCustomName.length > 0) {
        return trimmedCustomName;
    }
    if (!projectPath) {
        return 'Unknown Project';
    }
    return path.basename(projectPath) || projectPath;
}
/**
 * Application service for provider-backed session message operations.
 *
 * Callers pass a provider id and this service resolves the concrete provider
 * class, keeping normalization/history call sites decoupled from implementation
 * file layout.
 */
export const sessionsService = {
    /**
     * Lists provider ids that can load session history and normalize live messages.
     */
    listProviderIds() {
        return providerRegistry.listProviders().map((provider) => provider.id);
    },
    /**
     * Returns app-facing ids for provider runs that are currently processing.
     *
     * This is intentionally status-only: callers that only need sidebar activity
     * indicators should not attach to chat streams or request replayed messages.
     */
    listRunningSessions() {
        return chatRunRegistry.listRunningRuns();
    },
    /**
     * Returns the active conversation feed in true global activity order.
     */
    listRecentSessions(limit, offset) {
        const page = sessionsDb.getRecentSessionsPage(limit, offset);
        const projectCache = new Map();
        const conversations = page.sessions.map((session) => {
            const projectPath = session.project_path?.trim() ? session.project_path : null;
            let project = null;
            if (projectPath) {
                if (!projectCache.has(projectPath)) {
                    projectCache.set(projectPath, projectsDb.getProjectPath(projectPath));
                }
                project = projectCache.get(projectPath) ?? null;
            }
            return {
                sessionId: session.session_id,
                provider: session.provider,
                projectId: project?.project_id ?? null,
                projectDisplayName: resolveProjectDisplayName(projectPath, project?.custom_project_name),
                sessionTitle: session.custom_name?.trim() || session.session_id,
                lastActivity: session.updated_at ?? session.created_at ?? null,
            };
        });
        return {
            conversations,
            total: page.total,
            hasMore: offset + conversations.length < page.total,
        };
    },
    /**
     * Resolves the provider-native session id a runtime needs for resume.
     *
     * Callers hand provider runtimes the stable app session id; the provider
     * CLIs/SDKs only understand their own native id, which lives on the session
     * row. Ids without a row are assumed to be provider-native already (direct
     * API callers that reference sessions the watcher has not indexed yet).
     */
    resolveProviderSessionId(sessionId) {
        if (!sessionId) {
            return null;
        }
        const session = sessionsDb.getSessionById(sessionId);
        return session ? session.provider_session_id : sessionId;
    },
    /**
     * Normalizes one provider-native event into frontend session message events.
     */
    normalizeMessage(providerName, raw, sessionId) {
        return providerRegistry.resolveProvider(providerName).sessions.normalizeMessage(raw, sessionId);
    },
    /**
     * Allocates a stable app-facing session id before any provider run happens.
     *
     * This is the entry point of the session gateway: the frontend calls this
     * (via `POST /api/providers/sessions`) when the user starts a brand-new
     * chat, navigates to the returned id immediately, and the id never changes
     * for the lifetime of the conversation. The provider-native id is mapped to
     * this row later, when the provider runtime announces it mid-run. Its title
     * comes directly from the first visible CloudCLI message and is limited to
     * four whole words before any provider-owned storage exists.
     */
    createAppSession(provider, projectPath, initialMessage) {
        const normalizedProjectPath = projectPath.trim();
        if (!normalizedProjectPath) {
            throw new AppError('projectPath is required.', {
                code: 'PROJECT_PATH_REQUIRED',
                statusCode: 400,
            });
        }
        const sessionId = randomUUID();
        const sessionName = buildCloudCliSessionName(initialMessage);
        sessionsDb.createAppSession(sessionId, provider, normalizedProjectPath, sessionName);
        return {
            sessionId,
            provider,
            projectPath: normalizedProjectPath,
            sessionName,
        };
    },
    /**
     * Branches a session into an independent one containing its conversation up
     * to `upToAnchorId` (the whole thing when omitted).
     *
     * The source is left completely untouched — this is the "try two approaches"
     * action, not a destructive one.
     */
    async forkSessionById(sessionId, options = {}) {
        const source = sessionsDb.getSessionById(sessionId);
        if (!source) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        const provider = source.provider;
        const fork = providerRegistry.resolveProvider(provider).fork;
        if (!fork) {
            throw new AppError(`Sessions cannot be forked for provider "${provider}".`, {
                code: 'FORK_NOT_SUPPORTED',
                statusCode: 409,
            });
        }
        // A session that has never run has no transcript to copy, so there is
        // nothing a fork of it could resume from.
        if (!source.provider_session_id || !source.jsonl_path) {
            throw new AppError('This session has not produced a transcript yet.', {
                code: 'FORK_SOURCE_NOT_READY',
                statusCode: 409,
            });
        }
        const sessionName = options.title?.trim()
            || `${source.custom_name?.trim() || 'Session'} (fork)`;
        const forked = await fork.forkSession({
            providerSessionId: source.provider_session_id,
            jsonlPath: source.jsonl_path,
            projectPath: source.project_path ?? '',
            upToAnchorId: options.upToAnchorId,
            title: sessionName,
        });
        const forkSessionId = randomUUID();
        sessionsDb.createForkedSession({
            sessionId: forkSessionId,
            provider,
            projectPath: source.project_path ?? '',
            customName: sessionName,
            providerSessionId: forked.providerSessionId,
            jsonlPath: forked.jsonlPath,
            forkedFromSessionId: sessionId,
            // A fork that silently dropped to the catalog default would answer
            // differently from the conversation it was branched from.
            model: source.model,
            effort: source.effort,
        });
        await broadcastSessionUpserted(forkSessionId);
        return {
            sessionId: forkSessionId,
            provider,
            projectPath: source.project_path ?? '',
            sessionName,
        };
    },
    /**
     * Resolves the provider-native id only for an explicit user copy action.
     * Normal session payloads continue to expose only the stable app id.
     */
    getProviderSessionId(sessionId) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        if (!session.provider_session_id) {
            throw new AppError('This session ID is not available yet.', {
                code: 'PROVIDER_SESSION_ID_NOT_AVAILABLE',
                statusCode: 409,
            });
        }
        return session.provider_session_id;
    },
    /**
     * Fetches persisted history by app session id.
     *
     * Provider and provider-specific lookup hints are resolved from the indexed
     * session metadata in the database. The provider adapter receives the
     * provider-native session id (the one written into transcripts on disk),
     * and every returned message is remapped back to the app session id so
     * provider ids never reach the frontend.
     */
    /**
     * Resolves where a conversation must resume from so that one already-sent
     * message, and everything after it, is replaced.
     *
     * Returns `null` when the provider cannot do this at all, which is how the
     * chat gateway knows to refuse the request rather than silently sending the
     * edit as a new message at the end of the conversation.
     */
    async resolveEditAnchor(sessionId, anchorId) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        const sessions = providerRegistry.resolveProvider(session.provider).sessions;
        if (!sessions.resolveEditAnchor) {
            return null;
        }
        return sessions.resolveEditAnchor(sessionId, anchorId);
    },
    /**
     * Whether editing a message on this session's provider means rewinding it on
     * disk first, rather than handing the anchor to the runtime as a resume
     * option.
     *
     * Answering this without doing anything is the point: the rewind moves the
     * session onto a different provider transcript and cannot be undone, so the
     * gateway has to know which shape the run takes before it commits to one.
     */
    providerRewindsForEdit(sessionId) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        return Boolean(providerRegistry.resolveProvider(session.provider).sessions.rewindSession);
    },
    /**
     * Rewinds a session on disk so `keepThroughId` is the last row it holds.
     *
     * Only call this once the run is admitted — see `providerRewindsForEdit`.
     */
    async rewindSessionForEdit(sessionId, keepThroughId) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        const sessions = providerRegistry.resolveProvider(session.provider).sessions;
        await sessions.rewindSession?.(sessionId, keepThroughId);
    },
    async fetchHistory(sessionId, options = {}) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        // App-created sessions that never produced a provider transcript yet
        // (e.g. first message still streaming) simply have no history.
        if (!session.provider_session_id) {
            return {
                messages: [],
                total: 0,
                hasMore: false,
                offset: options.offset ?? 0,
                limit: options.limit ?? null,
            };
        }
        const provider = session.provider;
        const providerSessions = providerRegistry.resolveProvider(provider).sessions;
        const providerSessionId = session.provider_session_id;
        const projectPath = session.project_path ?? '';
        const requestedLimit = options.limit ?? null;
        const requestedOffset = options.offset ?? 0;
        // Claude and Codex history readers parse `jsonl_path` itself, so a page
        // can be sliced from the stat-validated full-transcript cache instead of
        // re-parsing the whole file per request. Cursor and OpenCode read their
        // messages from elsewhere (store.db / shared SQLite), so that file's stat
        // says nothing about their history — they stay on the direct path.
        const transcriptPath = provider === 'claude' || provider === 'codex'
            ? session.jsonl_path
            : null;
        const fullHistory = await sessionHistoryCache.getFullHistory({
            sessionId,
            transcriptPath,
            loadFull: () => providerSessions.fetchHistory(sessionId, {
                limit: null,
                offset: 0,
                projectPath,
                providerSessionId,
            }),
        });
        let result;
        if (fullHistory) {
            // Providers slice with this same helper, so a cached page is identical
            // to what a direct `(limit, offset)` read would have returned.
            const { page, hasMore } = sliceTailPage(fullHistory.messages, requestedLimit, Math.max(0, requestedOffset));
            result = {
                ...fullHistory,
                messages: page,
                hasMore,
                offset: requestedOffset,
                limit: requestedLimit,
            };
        }
        else {
            result = await providerSessions.fetchHistory(sessionId, {
                limit: requestedLimit,
                offset: requestedOffset,
                projectPath,
                providerSessionId,
            });
        }
        return {
            ...result,
            messages: result.messages.map((message) => ({
                ...message,
                sessionId,
            })),
        };
    },
    /**
     * Resolves one session (by app id, falling back to the provider-native id)
     * to its metadata plus the owning project.
     *
     * This backs deep links like `/session/:sessionId`: the frontend's paginated
     * project payloads only carry each project's first session page, so a
     * session opened directly by URL may not be present client-side at all —
     * this lookup is the authoritative way to learn which project owns it.
     */
    getSessionDetailsById(sessionId) {
        const session = sessionsDb.getSessionById(sessionId) ?? sessionsDb.getSessionByProviderSessionId(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        const projectPath = session.project_path?.trim() ? session.project_path : null;
        const project = projectPath ? projectsDb.getProjectPath(projectPath) : null;
        return {
            sessionId: session.session_id,
            provider: session.provider,
            summary: session.custom_name?.trim() || '',
            createdAt: session.created_at ?? null,
            updatedAt: session.updated_at ?? null,
            lastActivity: session.updated_at ?? session.created_at ?? null,
            isArchived: Boolean(session.isArchived),
            project: project && projectPath
                ? {
                    projectId: project.project_id,
                    path: projectPath,
                    fullPath: projectPath,
                    displayName: resolveProjectDisplayName(projectPath, project.custom_project_name),
                    isStarred: Boolean(project.isStarred),
                    isArchived: Boolean(project.isArchived),
                }
                : null,
        };
    },
    /**
     * Returns archived sessions with enough project metadata for the sidebar to
     * group, filter, open, and restore them without a per-row follow-up query.
     */
    listArchivedSessions() {
        const archivedSessions = sessionsDb.getArchivedSessions();
        const projectCache = new Map();
        return archivedSessions.map((session) => {
            const projectPath = session.project_path?.trim() ? session.project_path : null;
            let project = null;
            if (projectPath) {
                if (!projectCache.has(projectPath)) {
                    projectCache.set(projectPath, projectsDb.getProjectPath(projectPath));
                }
                project = projectCache.get(projectPath) ?? null;
            }
            return {
                sessionId: session.session_id,
                provider: session.provider,
                projectId: project?.project_id ?? null,
                projectPath,
                projectDisplayName: resolveProjectDisplayName(projectPath, project?.custom_project_name),
                sessionTitle: session.custom_name?.trim() || session.session_id,
                createdAt: session.created_at ?? null,
                updatedAt: session.updated_at ?? null,
                lastActivity: session.updated_at ?? session.created_at ?? null,
                isProjectArchived: Boolean(project?.isArchived),
            };
        });
    },
    /**
     * Archives or permanently deletes one persisted session row by id.
     *
     * Soft-delete mirrors the project behavior by toggling `isArchived` so the
     * row disappears from active lists but remains restorable. Force-delete
     * optionally removes the transcript file before deleting the database row.
     */
    async deleteOrArchiveSessionById(sessionId, options = {}) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        if (!options.force) {
            sessionsDb.updateSessionIsArchived(sessionId, true);
            return {
                sessionId,
                action: 'archived',
                deletedFromDisk: false,
            };
        }
        let removedFromDisk = false;
        if (options.deletedFromDisk) {
            // Every file the conversation has lived in, not just the one the row
            // points at now: editing a message on a provider that rewinds by
            // branching moves the session onto a copy and leaves the earlier
            // transcript behind. Deleting only the current one would leave the
            // replaced turns on disk, and unreachable through the app.
            const transcripts = [
                ...(session.jsonl_path ? [session.jsonl_path] : []),
                ...sessionsDb.getSupersededTranscriptPaths(sessionId),
            ];
            for (const transcript of transcripts) {
                removedFromDisk = (await removeFileIfExists(transcript)) || removedFromDisk;
            }
        }
        sessionsDb.clearSupersededProviderSessions(sessionId);
        const deleted = sessionsDb.deleteSessionById(sessionId);
        if (!deleted) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        return {
            sessionId,
            action: 'deleted',
            deletedFromDisk: removedFromDisk,
        };
    },
    /**
     * Restores one archived session back into the active sidebar lists.
     */
    restoreSessionById(sessionId) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        sessionsDb.updateSessionIsArchived(sessionId, false);
        return { sessionId, isArchived: false };
    },
    /**
     * Renames one session by id without requiring the caller to pass provider.
     */
    renameSessionById(sessionId, summary) {
        const session = sessionsDb.getSessionById(sessionId);
        if (!session) {
            throw new AppError(`Session "${sessionId}" was not found.`, {
                code: 'SESSION_NOT_FOUND',
                statusCode: 404,
            });
        }
        sessionsDb.updateSessionCustomName(sessionId, summary);
        return { sessionId, summary };
    },
};
//# sourceMappingURL=sessions.service.js.map