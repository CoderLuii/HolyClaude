import { readFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import TOML from '@iarna/toml';
import { buildDefaultProviderCurrentActiveModel, readObjectRecord, readOptionalString, } from '../../../../shared/utils.js';
/** Curated Codex catalog shipped as immutable CloudCLI defaults. */
export const CODEX_PREDEFINED_MODELS = {
    OPTIONS: [
        {
            value: 'gpt-6-astra',
            label: 'GPT-6 Astra',
            description: 'Our most capable model for complex, demanding work.',
            effort: {
                default: 'low',
                values: [
                    { value: 'low' },
                    { value: 'medium' },
                    { value: 'high' },
                    { value: 'xhigh' },
                    { value: 'max' },
                    { value: 'ultra' },
                ],
            },
        },
        {
            value: 'gpt-5.6-sol',
            label: 'GPT-5.6 Sol',
            description: 'Latest frontier agentic coding model.',
            effort: {
                default: 'low',
                values: [
                    { value: 'low' },
                    { value: 'medium' },
                    { value: 'high' },
                    { value: 'xhigh' },
                    { value: 'max' },
                    { value: 'ultra' },
                ],
            },
        },
        {
            value: 'gpt-5.6-terra',
            label: 'GPT-5.6 Terra',
            description: 'Balanced agentic coding model for everyday work.',
            effort: {
                default: 'medium',
                values: [
                    { value: 'low' },
                    { value: 'medium' },
                    { value: 'high' },
                    { value: 'xhigh' },
                    { value: 'max' },
                    { value: 'ultra' },
                ],
            },
        },
        {
            value: 'gpt-5.6-luna',
            label: 'GPT-5.6 Luna',
            description: 'Fast and affordable agentic coding model.',
            effort: {
                default: 'medium',
                values: [
                    { value: 'low' },
                    { value: 'medium' },
                    { value: 'high' },
                    { value: 'xhigh' },
                    { value: 'max' },
                ],
            },
        },
        {
            value: 'gpt-5.5',
            label: 'GPT-5.5',
            description: 'Frontier model for complex coding, research, and real-world work.',
            effort: {
                default: 'medium',
                values: [{ value: 'low' }, { value: 'medium' }, { value: 'high' }, { value: 'xhigh' }],
            },
        },
        {
            value: 'gpt-5.4',
            label: 'GPT-5.4',
            description: 'Strong model for everyday coding.',
            effort: {
                default: 'medium',
                values: [{ value: 'low' }, { value: 'medium' }, { value: 'high' }, { value: 'xhigh' }],
            },
        },
        {
            value: 'gpt-5.4-mini',
            label: 'GPT-5.4 Mini',
            description: 'Small, fast, and cost-efficient model for simpler coding tasks.',
            effort: {
                default: 'medium',
                values: [{ value: 'low' }, { value: 'medium' }, { value: 'high' }, { value: 'xhigh' }],
            },
        },
    ],
    DEFAULT: 'gpt-5.6-sol',
};
const CODEX_CONFIG_PATH = path.join(os.homedir(), '.codex', 'config.toml');
/** Provider registry model adapter for Codex predefined models and active config. */
export class CodexProviderModels {
    async getSupportedModels() {
        return CODEX_PREDEFINED_MODELS;
    }
    async getCurrentActiveModel() {
        try {
            const raw = await readFile(CODEX_CONFIG_PATH, 'utf8');
            const parsed = readObjectRecord(TOML.parse(raw));
            const model = readOptionalString(parsed?.model);
            if (!model) {
                return buildDefaultProviderCurrentActiveModel(await this.getSupportedModels());
            }
            return {
                model,
            };
        }
        catch {
            return buildDefaultProviderCurrentActiveModel(await this.getSupportedModels());
        }
    }
}
//# sourceMappingURL=codex-models.provider.js.map