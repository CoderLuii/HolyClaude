import assert from 'node:assert/strict';
import { once } from 'node:events';
import test from 'node:test';
import { WebSocket, WebSocketServer } from 'ws';
import { registerAuthenticatedWebSocket, revokeAuthenticatedWebSockets, } from '../../../modules/auth/auth-session-registry.js';
class FakeSocket {
    readyState = 1;
    closeCalls = [];
    closeListeners = [];
    close(code, reason) {
        this.closeCalls.push({ code, reason });
    }
    once(_event, listener) {
        this.closeListeners.push(listener);
    }
    removeAllListeners(_event) {
        return this;
    }
    terminate() {
        this.readyState = 3;
    }
    emitClose() {
        for (const listener of this.closeListeners.splice(0)) {
            listener();
        }
    }
}
test('password rotation closes every authenticated socket for that account only', () => {
    const first = new FakeSocket();
    const second = new FakeSocket();
    const otherUser = new FakeSocket();
    registerAuthenticatedWebSocket(first, { userId: 7 });
    registerAuthenticatedWebSocket(second, { id: 7 });
    registerAuthenticatedWebSocket(otherUser, { userId: 8 });
    revokeAuthenticatedWebSockets(7);
    assert.deepEqual(first.closeCalls, [{ code: 4001, reason: 'Authentication revoked' }]);
    assert.deepEqual(second.closeCalls, [{ code: 4001, reason: 'Authentication revoked' }]);
    assert.deepEqual(otherUser.closeCalls, []);
});
test('a delayed old close cannot remove sockets registered after rotation', () => {
    const oldSocket = new FakeSocket();
    registerAuthenticatedWebSocket(oldSocket, { userId: 9 });
    revokeAuthenticatedWebSockets(9);
    const replacementSocket = new FakeSocket();
    registerAuthenticatedWebSocket(replacementSocket, { userId: 9 });
    oldSocket.emitClose();
    revokeAuthenticatedWebSockets(9);
    assert.deepEqual(replacementSocket.closeCalls, [{ code: 4001, reason: 'Authentication revoked' }]);
});
test('revocation disables live inbound dispatch before a delayed close and terminates the socket', async () => {
    const server = new WebSocketServer({ port: 0, host: '127.0.0.1' });
    await once(server, 'listening');
    const address = server.address();
    const client = new WebSocket(`ws://127.0.0.1:${address.port}`);
    const [socket] = await once(server, 'connection');
    await once(client, 'open');
    try {
        let privilegedDispatches = 0;
        socket.on('message', () => {
            privilegedDispatches += 1;
        });
        const firstMessage = once(socket, 'message');
        client.send('before-rotation');
        await Promise.race([
            firstMessage,
            new Promise((_, reject) => setTimeout(() => reject(new Error('initial message timed out')), 1_000)),
        ]);
        const closeCalls = [];
        socket.close = ((code, reason) => {
            closeCalls.push({ code, reason: reason?.toString() });
        });
        registerAuthenticatedWebSocket(socket, { userId: 11 });
        revokeAuthenticatedWebSockets(11);
        client.send('after-rotation');
        await new Promise((resolve) => setTimeout(resolve, 25));
        assert.equal(privilegedDispatches, 1, 'no inbound frame may dispatch after revocation starts');
        assert.deepEqual(closeCalls, [{ code: 4001, reason: 'Authentication revoked' }]);
        await once(client, 'close');
        assert.equal(client.readyState, WebSocket.CLOSED, 'a close that stalls must be terminated');
    }
    finally {
        if (client.readyState !== WebSocket.CLOSED)
            client.terminate();
        for (const openSocket of server.clients)
            openSocket.terminate();
        await new Promise((resolve) => server.close(() => resolve()));
    }
});
//# sourceMappingURL=auth-session-registry.test.js.map