const socketsByUserId = new Map();
const AUTHENTICATION_REVOKE_TERMINATE_DELAY_MS = 1_000;
const WEBSOCKET_CLOSED_STATE = 3;
const normalizeUserId = (user) => {
    const userId = user.userId ?? user.id;
    return userId == null ? null : String(userId);
};
export function registerAuthenticatedWebSocket(socket, user) {
    if (!user)
        return;
    const userId = normalizeUserId(user);
    if (!userId)
        return;
    const sockets = socketsByUserId.get(userId) ?? new Set();
    sockets.add(socket);
    socketsByUserId.set(userId, sockets);
    socket.once('close', () => {
        sockets.delete(socket);
        if (sockets.size === 0 && socketsByUserId.get(userId) === sockets) {
            socketsByUserId.delete(userId);
        }
    });
}
export function revokeAuthenticatedWebSockets(userId) {
    const normalizedUserId = String(userId);
    const sockets = socketsByUserId.get(normalizedUserId);
    if (!sockets)
        return;
    socketsByUserId.delete(normalizedUserId);
    for (const socket of sockets) {
        socket.removeAllListeners('message');
        const terminateTimer = setTimeout(() => {
            if (socket.readyState !== WEBSOCKET_CLOSED_STATE) {
                socket.terminate();
            }
        }, AUTHENTICATION_REVOKE_TERMINATE_DELAY_MS);
        terminateTimer.unref();
        socket.once('close', () => clearTimeout(terminateTimer));
        try {
            socket.close(4001, 'Authentication revoked');
        }
        catch {
            clearTimeout(terminateTimer);
            socket.terminate();
        }
    }
}
//# sourceMappingURL=auth-session-registry.js.map