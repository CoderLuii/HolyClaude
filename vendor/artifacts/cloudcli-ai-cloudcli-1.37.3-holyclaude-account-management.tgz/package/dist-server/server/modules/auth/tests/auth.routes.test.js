import assert from 'node:assert/strict';
import { once } from 'node:events';
import test from 'node:test';
import express from 'express';
import { createAuthRouter } from '../../../modules/auth/auth.routes.js';
import { createAuthService } from '../../../modules/auth/auth.service.js';
import { AppError } from '../../../shared/utils.js';
test('change-password returns 400 for an absent request body', async () => {
    const dependencies = {
        isPlatform: false,
    };
    const service = createAuthService(dependencies);
    const app = express();
    app.use(express.json());
    app.use('/api/auth', createAuthRouter(service, (req, _res, next) => {
        req.user = { id: 1, username: 'alice' };
        next();
    }));
    app.use((error, _req, res, _next) => {
        if (error instanceof AppError) {
            res.status(error.statusCode).json({ error: error.code });
            return;
        }
        res.status(500).json({ error: 'INTERNAL_ERROR' });
    });
    const server = app.listen(0, '127.0.0.1');
    await once(server, 'listening');
    try {
        const address = server.address();
        for (const request of [
            { method: 'POST' },
            { method: 'POST', headers: { 'content-type': 'text/plain' }, body: 'not-json' },
        ]) {
            const response = await fetch(`http://127.0.0.1:${address.port}/api/auth/change-password`, request);
            const payload = await response.json();
            assert.equal(response.status, 400);
            assert.equal(payload.error, 'AUTH_PASSWORDS_REQUIRED');
        }
    }
    finally {
        await new Promise((resolve, reject) => {
            server.close((error) => error ? reject(error) : resolve());
        });
    }
});
//# sourceMappingURL=auth.routes.test.js.map