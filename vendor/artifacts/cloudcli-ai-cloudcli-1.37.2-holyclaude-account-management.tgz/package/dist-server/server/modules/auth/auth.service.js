import { AppError } from '../../shared/utils.js';
function numericUserId(userId) {
    return Number(userId);
}
function isUniqueConstraintError(error) {
    return typeof error === 'object'
        && error !== null
        && 'code' in error
        && error.code === 'SQLITE_CONSTRAINT_UNIQUE';
}
/**
 * Creates the Auth application service around explicit persistence, crypto,
 * transaction, and token dependencies.
 */
export function createAuthService(dependencies) {
    return {
        getStatus() {
            return {
                needsSetup: !dependencies.users.hasUsers(),
                isAuthenticated: false,
            };
        },
        async register(usernameInput, passwordInput) {
            const username = typeof usernameInput === 'string' ? usernameInput : '';
            const password = typeof passwordInput === 'string' ? passwordInput : '';
            if (!username || !password) {
                throw new AppError('Username and password are required', {
                    code: 'AUTH_CREDENTIALS_REQUIRED',
                    statusCode: 400,
                });
            }
            if (username.length < 3 || password.length < 6) {
                throw new AppError('Username must be at least 3 characters, password at least 6 characters', { code: 'AUTH_CREDENTIALS_TOO_SHORT', statusCode: 400 });
            }
            dependencies.transaction.begin();
            try {
                if (dependencies.users.hasUsers()) {
                    throw new AppError('User already exists. This is a single-user system.', {
                        code: 'AUTH_USER_ALREADY_CONFIGURED',
                        statusCode: 403,
                    });
                }
                const passwordHash = await dependencies.hashPassword(password);
                const user = dependencies.users.createUser(username, passwordHash);
                const token = dependencies.generateToken(user);
                dependencies.transaction.commit();
                dependencies.users.updateLastLogin(numericUserId(user.id));
                return {
                    success: true,
                    user: { id: user.id, username: user.username },
                    token,
                };
            }
            catch (error) {
                dependencies.transaction.rollback();
                if (isUniqueConstraintError(error)) {
                    throw new AppError('Username already exists', {
                        code: 'AUTH_USERNAME_CONFLICT',
                        statusCode: 409,
                    });
                }
                throw error;
            }
        },
        async login(usernameInput, passwordInput) {
            const username = typeof usernameInput === 'string' ? usernameInput : '';
            const password = typeof passwordInput === 'string' ? passwordInput : '';
            if (!username || !password) {
                throw new AppError('Username and password are required', {
                    code: 'AUTH_CREDENTIALS_REQUIRED',
                    statusCode: 400,
                });
            }
            const user = dependencies.users.getUserByUsername(username);
            const validPassword = user
                ? await dependencies.comparePassword(password, user.password_hash)
                : false;
            if (!user || !validPassword) {
                throw new AppError('Invalid username or password', {
                    code: 'AUTH_INVALID_CREDENTIALS',
                    statusCode: 401,
                });
            }
            dependencies.users.updateLastLogin(numericUserId(user.id));
            return {
                success: true,
                user: { id: user.id, username: user.username },
                token: dependencies.generateToken(user),
            };
        },
        getCurrentUser(user) {
            return { user };
        },
        refreshSession(user) {
            if (typeof user !== 'object'
                || user === null
                || !('id' in user)
                || !('username' in user)
                || (typeof user.id !== 'number' && typeof user.id !== 'bigint')
                || typeof user.username !== 'string') {
                throw new AppError('Authenticated user is required', {
                    code: 'AUTH_USER_REQUIRED',
                    statusCode: 401,
                });
            }
            return { token: dependencies.generateToken(user) };
        },
        logout() {
            return { success: true, message: 'Logged out successfully' };
        },
        async changePassword(userInput, currentPasswordInput, newPasswordInput) {
            if (dependencies.isPlatform) {
                throw new AppError('Password changes are not available in platform mode', {
                    code: 'AUTH_PASSWORD_CHANGE_UNAVAILABLE', statusCode: 403,
                });
            }
            const currentPassword = typeof currentPasswordInput === 'string' ? currentPasswordInput : '';
            const newPassword = typeof newPasswordInput === 'string' ? newPasswordInput : '';
            if (!currentPassword || !newPassword) {
                throw new AppError('Current password and new password are required', {
                    code: 'AUTH_PASSWORDS_REQUIRED', statusCode: 400,
                });
            }
            if (newPassword.length < 6) {
                throw new AppError('New password must be at least 6 characters', {
                    code: 'AUTH_PASSWORD_TOO_SHORT', statusCode: 400,
                });
            }
            if (typeof userInput !== 'object' || userInput === null || !('id' in userInput)) {
                throw new AppError('Authenticated user is required', {
                    code: 'AUTH_USER_REQUIRED', statusCode: 401,
                });
            }
            const user = dependencies.users.getUserAuthById(numericUserId(userInput.id));
            if (!user || !(await dependencies.comparePassword(currentPassword, user.password_hash))) {
                throw new AppError('Current password is incorrect', {
                    code: 'AUTH_CURRENT_PASSWORD_INVALID', statusCode: 401,
                });
            }
            const passwordHash = await dependencies.hashPassword(newPassword);
            dependencies.transaction.begin();
            try {
                dependencies.users.updatePasswordHash(numericUserId(user.id), passwordHash);
                dependencies.appConfig.set('auth_token_generation', dependencies.randomUUID());
                dependencies.transaction.commit();
            }
            catch (error) {
                dependencies.transaction.rollback();
                throw error;
            }
            return { success: true, message: 'Password updated. Please sign in again.' };
        },
    };
}
//# sourceMappingURL=auth.service.js.map