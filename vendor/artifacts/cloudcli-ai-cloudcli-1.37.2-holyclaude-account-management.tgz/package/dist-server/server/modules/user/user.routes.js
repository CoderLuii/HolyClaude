import express from 'express';
function readUserId(request) {
    const rawUserId = request.user?.id;
    return Number(rawUserId);
}
/** Creates thin user routes that parse authenticated input and call the service. */
export function createUserRouter(service) {
    const router = express.Router();
    router.get('/git-config', async (req, res, next) => {
        try {
            res.json(await service.getGitConfig(readUserId(req)));
        }
        catch (error) {
            next(error);
        }
    });
    router.post('/git-config', async (req, res, next) => {
        try {
            const body = req.body;
            res.json(await service.updateGitConfig(readUserId(req), body.gitName, body.gitEmail));
        }
        catch (error) {
            next(error);
        }
    });
    router.post('/complete-onboarding', (req, res, next) => {
        try {
            res.json(service.completeOnboarding(readUserId(req)));
        }
        catch (error) {
            next(error);
        }
    });
    router.get('/onboarding-status', (req, res, next) => {
        try {
            res.json(service.getOnboardingStatus(readUserId(req)));
        }
        catch (error) {
            next(error);
        }
    });
    return router;
}
//# sourceMappingURL=user.routes.js.map